# README

## “`catr` package: an ‘engine’ for making single geo-year MOVES runs.”

This repository contains all data necessary for building the `catr`
package. As long as you download the repository and install the package
once, you can use it any time on that computer, in any repository.

### 0. Packages

Let’s load the `install_it()` function from `demo/install_it.R`.

    source("demo/install_it.R")
    install_it(); remove(install_it)

Load packages!

    # Load catr!
    library(catr)
    # Let's also load some other packages
    library(readr)
    library(dplyr)

### 1. \`setup()

Run `setup()` to execute our setup wizard, which will notify you if you
are not ready to run normal inputter functions. Triggers
`ready_packages()`, `ready_keys()`, `ready_sqlite()`, and
`ready_templates()`.

In order to pass all checks, you will to have installed all packages in
`ready_packages()`, and you will need a fully operational `keys.R`
script and an existing default sqlite database. `setup()` should guide
you through this process, so it shouldn’t be necessary to run these
scripts separately.

    # Create a new keys.R script, including your username and password for CLOUD SQL.
    setup(force = TRUE, username = 'myusername', password = 'mypassword')

    ## [1] "...making a keys.R file template..."
    ## ----------------------------------------
    ## SETUP COMPLETE.  READY!
    ## ----------------------------------------

Any subsequent time during the same session, you can just run `setup()`
and it will read your `keys.R` file.

    setup()

    ## ----------------------------------------
    ## SETUP COMPLETE.  READY!
    ## ----------------------------------------

### 2. `engine()`

Want a single, one-line function? Use `engine()`.

    engine(
      # Core inputs  
      changes = c("demo/startsperdaypervehicle.csv", "demo/sourcetypeyear.csv"), 
        level = "county", geoid = "36109", year = 2020, id = 1000, 
      # Default Settings Inputs (don't have to include these)
        default = FALSE, adapt = TRUE, invoke = TRUE, background = FALSE, format_n = 1, 
      # Transfer to CLOUD SQL? (by default, transfer = FALSE, just to protect us)
        transfer = FALSE, cdbname = "test", table = "testtable", overwrite = TRUE)

If you want to do it step by step, use these settings below.

### 3. Make parameters

Next, let’s say you have 2 input tables you want to add to a custom
input database, where their names match the tables they aim to replace.
We can go through the steps for processing that data below.

Let’s make a `list()` of parameters `p` that we will supply to our
`catr` engine.

    # Make parameters
    p = list(
      changes = c("demo/startsperdaypervehicle.csv", "demo/sourcetypeyear.csv"),
      level = "county", geoid = "36109", year = 2020, default = FALSE,
      id = 1000 # ID is really optional.
    )

For example, here is our first table, which has been edited slightly, as
seen in `demo/demo_data.R`.

    p$changes[1] %>% read_csv() %>% glimpse()

    ## Rows: 26
    ## Columns: 3
    ## $ dayID                  <dbl> 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5,…
    ## $ sourceTypeID           <dbl> 11, 21, 31, 32, 41, 42, 43, 51, 52, 53, 54, 61,…
    ## $ startsPerDayPerVehicle <dbl> 0.33148253, 3.13035496, 3.32176408, 3.52499858,…

### 4. Make Custom Runspec

Next, let’s make a custom runspec that matches our input parameters.

    # Make a custom runspec!
    p$runspec = custom_rs(
      .level = p$level, .geoid = p$geoid, .year = p$year, 
      .id = p$id, .default = p$default)

    ## [1] "36109-2020-custom--- done!"

    # View the runspec path!
    p$runspec

    ## [1] "C:/Users/tmf77/OneDrive - Cornell University/Documents/rs_36109_2020_rs_moves31_custom_1000.xml"

### 5. `adapt()` input database

Next, let’s adapt the input database.

    adapt(.changes = p$changes, .runspec = p$runspec)

### 6. `invoke_rs()`

Next, let’s invoke MOVES. You can invoke it as a background job
(`background = TRUE`), which is helpful when you’re doing other things
in R, but for a simple linear process, you might just want
`background = TRUE`.

    invoke_rs(.runspec = p$runspec, background = FALSE)

### 7. `get_runid()`

Next, let’s get the run ID of the most recent moves run you just did.

    p$run = get_runid(n = 1)
    # View it! (Yours might be different.)
    p$run

    ## [1] 10

### 8. `format_data()`

Next, let’s format the MOVES data into CAT format, saving the results as
a temporary .rds file.

    # Format it!
    p$path = format_data(
      .level = p$level, .geoid = p$geoid, 
      .run = p$run, 
      .pollutant = p$pollutant, .by = c(16, 8, 12, 14, 15))

    ## [1] "Assuming all values in .geoid are from the same state... Bad news if not..."
    ## [1] "---processing: done"
    ## [1] "---path:  C://Users//tmf77//OneDrive - Cornell University//Documents//file8dc8611d27e1.rds"

    # View result!
    p$path %>% read_rds() %>% head()

<table style="width:100%;">
<colgroup>
<col style="width: 3%" />
<col style="width: 4%" />
<col style="width: 6%" />
<col style="width: 8%" />
<col style="width: 6%" />
<col style="width: 8%" />
<col style="width: 6%" />
<col style="width: 6%" />
<col style="width: 6%" />
<col style="width: 6%" />
<col style="width: 4%" />
<col style="width: 6%" />
<col style="width: 2%" />
<col style="width: 7%" />
<col style="width: 6%" />
<col style="width: 6%" />
<col style="width: 6%" />
</colgroup>
<thead>
<tr class="header">
<th style="text-align: right;">year</th>
<th style="text-align: left;">geoid</th>
<th style="text-align: right;">pollutant</th>
<th style="text-align: right;">emissions</th>
<th style="text-align: right;">vmt</th>
<th style="text-align: right;">sourcehours</th>
<th style="text-align: right;">vehicles</th>
<th style="text-align: right;">starts</th>
<th style="text-align: right;">idlehours</th>
<th style="text-align: right;">hoteld</th>
<th style="text-align: right;">hotelb</th>
<th style="text-align: right;">hotelo</th>
<th style="text-align: right;">by</th>
<th style="text-align: right;">sourcetype</th>
<th style="text-align: right;">regclass</th>
<th style="text-align: right;">fueltype</th>
<th style="text-align: right;">roadtype</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">1</td>
<td style="text-align: right;">90.324199</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
<tr class="even">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">2</td>
<td style="text-align: right;">2357.280892</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
<tr class="odd">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">3</td>
<td style="text-align: right;">468.598307</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
<tr class="even">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">5</td>
<td style="text-align: right;">19.131808</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
<tr class="odd">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">6</td>
<td style="text-align: right;">2.018865</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
<tr class="even">
<td style="text-align: right;">2020</td>
<td style="text-align: left;">36109</td>
<td style="text-align: right;">31</td>
<td style="text-align: right;">2.219478</td>
<td style="text-align: right;">765333555</td>
<td style="text-align: right;">21004909</td>
<td style="text-align: right;">64029.7</td>
<td style="text-align: right;">78685157</td>
<td style="text-align: right;">14719.19</td>
<td style="text-align: right;">1104.183</td>
<td style="text-align: right;">0</td>
<td style="text-align: right;">3955.826</td>
<td style="text-align: right;">16</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
<td style="text-align: right;">NA</td>
</tr>
</tbody>
</table>

### 9. `transfer_data()`

Next, transfer your data! To do this, you’ll need your `CLOUD_USERNAME`
and `CLOUD_PASSWORD` filled in in your `keys.R` file, which we did using
`setup(force = TRUE, username = "blahblah", password = "yadayada')`.

    transfer_data(
      path = p$path, .level = p$level, .geoid = p$geoid, 
      .cdbname = "test", .table = "testtable", .overwrite = TRUE)
