#' `engine()`
#' 
#' A one-stop function for running the full `catr` suite of functions.
#' @param changes vector of paths to input tables. Names must match tables they will replace.
#' @param level eg. "county"
#' @param geoid eg. "36109"
#' @param year eg. 2020
#' @param id eg. 1000
#' @param pollutant typically NULL, for all pollutants.
#' @param by typically NULL, for all.
#' @param default Logical. For custom run, default = FALSE. Defaults to FALSE.
#' @param adapt Logical. Should you adapt the input database?
#' @param invoke Logical. Should you invoke MOVES, assuming you adapted the database?
#' @param background Logical. Run job in the main terminal (FALSE) or as a background job (TRUE)? 
#' @param format_n eg. 1. Number of most recent runs to format. Almost always 1.
#' @param transfer Logical. Should you transfer to Cloud SQL? TRUE/FALSE. Defaults to FALSE.
#' @param cloud DBI connection object for database to transfer to. Defaults to "NULL".
#' @param table String. Name of SQL table to make/overwrite.
#' @param overwrite Logical. Overwrite that SQL table, whether or not it exists?
#' @export
#' 

engine = function(changes = NULL, 
                  level, geoid, year, id = 1000, pollutant = NULL, by = NULL,
                  default = FALSE, adapt = TRUE, invoke = TRUE, background = FALSE, format_n = 1, 
                  transfer = FALSE, cloud = NULL, table = "name", overwrite = TRUE){
  
  # Testing values
  # changes = c("demo/startsperdaypervehicle.csv", "demo/sourcetypeyear.csv")
  # changes = NULL
  # level = "county"
  # geoid = "36109"
  # year = 2020
  # id = 1000
  # pollutant = NULL
  # by = NULL
  # # Other settings
  # default = FALSE
  # adapt = TRUE
  # invoke = TRUE
  # background = FALSE
  # format_n = 1
  # transfer = FALSE
  # cdbname = "test";
  # table = "testtable"; 
  # overwrite = FALSE
  
  # If blank, set by to:
  if(is.null(by)){ by = c(16, 8, 12, 14, 15) }  
  
  # Make parameters
  p = list(
    changes = changes,
    level = level, geoid = geoid, year = year, id = id, 
    pollutant = pollutant, by = by,
    # ID is really optional.
    # Background Settings
    default = default, adapt = adapt, invoke = invoke, background = background, format_n = format_n, 
    # Settings for Transfers
    transfer = transfer, table = table, overwrite = overwrite
  )
  
  
  # Make a custom runspec!
  p$runspec = custom_rs(
    .level = p$level, .geoid = p$geoid, .year = p$year, 
    .id = p$id, .default = p$default)
  
  # Adapt (and potentially Invoke)!
  if(adapt == TRUE){
    # View the runspec path!
    adapt(.changes = p$changes, .runspec = p$runspec)
    
    # Then, if INVOKE is TRUE
    if(invoke == TRUE){  
      # Invoke MOVES
      invoke_rs(.runspec = p$runspec, background = p$background)
    }
  }
  
  
  # Get id(s) for the last n runs
  p$run = get_runid(n = p$format_n)
  
  
  # Format it!
  p$path = format_data(
    .level = p$level, .geoid = p$geoid, .run = p$run, 
    .pollutant = p$pollutant, .by = p$by)
  
  # Transfer = TRUE
  if(transfer == TRUE){
    transfer_data(
      path = p$path, .level = p$level, .geoid = p$geoid, 
      con = cloud, .table = p$table, .overwrite = p$overwrite)
  }
  
  # Return settings list
  return(p)
  
}
