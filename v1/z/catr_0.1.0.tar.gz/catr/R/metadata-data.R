#' `metadata`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(metadata)
#' @format ## `metadata`
#' A list object containing lists for the `county`, `state`, and `nation` level, for the `emissions` and `activity` datsets.
#' \describe{
#'   \item{labels}{...}
#'   \item{type}{...}
#'   \item{headers}{...}
#'   \item{example}{...}
#'   \item{vars}{...}
#' ...
#' }
"metadata"