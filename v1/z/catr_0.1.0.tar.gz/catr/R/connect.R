#' `connect()`
#'
#' This function allows the user/session to connect to one of our frequently used database connections, depending on input criteria.
#' @param .type description TBA.
#' @param ... description TBA.
#' @importFrom DBI dbConnect
#' @importFrom RSQLite SQLite
#' @importFrom RMariaDB MariaDB
#' @export  

connect <- function(.type = "mariadb", ...){
  # For example... 
  # -- connect to cloud as connect("cloud", "data")
  # -- connect to mariadb as connect("mariadb", "nameofyourdatabase")
  
  con = switch(
    EXPR = .type,
    # Connect to local sqlite server
    "sqlite" = {  
      # Make Connection!
      DBI::dbConnect(RSQLite::SQLite(), ...)
    },
    
    # Connect to local Maria DB server 
    "mariadb" = {   
      # Load supplementary Packages
      DBI::dbConnect(
        RMariaDB::MariaDB(),
        username = Sys.getenv("MDB_USERNAME"),
        password = Sys.getenv("MDB_PASSWORD"),
        port = Sys.getenv("MDB_PORT"),
        host = Sys.getenv("MDB_HOST"), 
        # Database name (dbname) goes here
        dbname = ...)
    }
  )
  # Return connection object
  return(con)
}


