#' `tables`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(tables)
#' @format ## `tables`
#' A named data.frame with 40 rows and 3 columns:
#' \describe{
#'   \item{var}{Name of Default MOVES SQL DB table}
#'   \item{id}{Unique ID for table}
#'   \item{value}{"asis", "empty" or "Adjustable" or "filter}
#' ...
#' }
"tables"