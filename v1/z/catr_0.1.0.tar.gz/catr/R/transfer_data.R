#' `transfer_data()`
#'
#' Function to transfer temporary data file created in process_all.R 
#' to a Cloud SQL (MySQL) table, specified by default, or using .table.
#' @param path ...
#' @param con ...
#' @param .level ...
#' @param .geoid ...
#' @param .table ...
#' @param .overwrite ...
#' @import DBI
#' @import RMariaDB
#' @import RSQLite
#' @importFrom dplyr `%>%` filter
#' @importFrom readr read_rds
#' @importFrom stringr str_pad str_sub
#' @export
#' @author Tim Fraser, March 2023

transfer_data = function(path, .level = "state", .geoid = NULL, 
                         con, .table = NULL, .overwrite = FALSE){
  
  
  if(is.null(path)){ print("Stopping: path to temporary .rds file must be specified in `path`."); stop()   }
  
  # Load packages
  # require("dplyr", warn.conflicts = FALSE)
  # require("readr", warn.conflicts = FALSE)
  # require("stringr", warn.conflicts = FALSE)
  # require("DBI", warn.conflicts = FALSE)
  # require("RMySQL", warn.conflicts = FALSE)
  # 
  # Connect to Cloud SQL 'data' database 
  # con
  
  
  # If .table is not supplied, generate the .table name for cloud database   
  if(is.null(.table)){
    .table = switch(
      EXPR = .level,
      "nation" = { "nation" },
      "state" = {  "state" },
      "county" = { paste0("county_", .geoid[1] %>% str_pad(width = 5, pad = "0", side = "left") %>% str_sub(1,2)) },
      "project" = { print("TBD. STOP!"); stop() }
    )
  }
  
  # By default, we don't overwrite.
  # But we do need to check, does this table actually exist yet?
  # If not, this if() statement sets .overwrite to TRUE so you can write it to file.
  if(.overwrite == FALSE){
    
    # Check existing tables on our cloud database
    tabs = con %>% dbListTables()
    
    # If your name is NOT found in the existing tables, initialize it; otherwise, 
    # absolutely don't so you don't overwrite anything!
    if(!.table %in% tabs){ .overwrite = TRUE; .append = FALSE
    # Otherwise, just keep overwrite FALSE and append the tables
    }else{ .overwrite = FALSE; .append = TRUE }
    
    # If .overwrite = TRUE, set .append to FALSE
  }else{ .append = FALSE }
  
  fieldtypes = data("fieldtypes", envir = environment(), overwrite = TRUE)
  
  # Write a template to file.
  con %>% 
    dbWriteTable(
      conn = .,
      name = .table, 
      value = readr::read_rds(path), 
      # Get template of sQL field types from file
      field.types = fieldtypes,
      row.names = FALSE, 
      overwrite = .overwrite, 
      append = .append)
  
  # Print completion message
  paste0("done: ", .level, " .geoid: ", .geoid[1], "... ") %>% print()
  
  # Disconnect from local Cloud database (IMPORTANT) and remove irrelevant data
  dbDisconnect(con); remove(con)
  
  # Print completion message
  print("---transfer: done")
  
  # Clear cache
  gc()
  
}
