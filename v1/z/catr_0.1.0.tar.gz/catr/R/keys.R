#' @name keys.R
#' @title keys()
#' @description Set keys
#' @param SQLITE ...
#' @param MDB_USERNAME ...
#' @param MDB_PASSWORD ...
#' @param MDB_PORT ...
#' @param MDB_HOST ...
#' @param MDB_NAME ...
#' @param MDB_DEFAULT ...
#' @param INPUTDBNAME ...
#' @param INPUTSERVERNAME ...
#' @param OUTPUTDBNAME ...
#' @param OUTPUTSERVERNAME ...
#' @param RS_FOLDER ...
#' @param MOVES_FOLDER ...
#' @param TEMP_FOLDER ...
#' @export

keys = function(
    # Path to default sqlite db (by default, default.sqlite)
    SQLITE = "default.sqlite",
    # MariaDB MOVES DB info
    MDB_USERNAME = "moves",  
    MDB_PASSWORD = "moves",  
    MDB_PORT = "3306",  
    MDB_HOST = "localhost",  
    MDB_NAME = "moves",
    MDB_DEFAULT = "movesdb20221007",
    # Input / Output MariaDB Information
    #    update these with your info.
    INPUTDBNAME = "custom",
    INPUTSERVERNAME = "localhost",  
    OUTPUTDBNAME = "inputter",  
    OUTPUTSERVERNAME = "localhost",  
    # RUNSPEC INFORMATION
    #    update these with your info.
    RS_FOLDER = "rs",  
    # PATH TO MOVES DIRECTORY 
    MOVES_FOLDER = "C:/Users/Public/EPA/MOVES/MOVES3.1/",  
    TEMP_FOLDER = Sys.getenv("HOME")
){
  
  Sys.setenv(SQLITE = SQLITE)
  
  Sys.setenv(MDB_USERNAME = MDB_USERNAME)
  Sys.setenv(MDB_PASSWORD = MDB_PASSWORD)
  Sys.setenv(MDB_PORT = MDB_PORT)
  Sys.setenv(MDB_HOST = MDB_HOST)
  Sys.setenv(MDB_NAME = MDB_NAME)
  Sys.setenv(MDB_DEFAULT = MDB_DEFAULT)
  
  Sys.setenv(INPUTDBNAME = INPUTDBNAME)
  Sys.setenv(OUTPUTDBNAME = OUTPUTDBNAME)
  Sys.setenv(OUTPUTSERVERNAME = OUTPUTSERVERNAME)
  Sys.setenv(INPUTSERVERNAME = INPUTSERVERNAME)
  
  Sys.setenv(RS_FOLDER = RS_FOLDER)
  Sys.setenv(MOVES_FOLDER = MOVES_FOLDER)
  Sys.setenv(TEMP_FOLDER = TEMP_FOLDER)
  
}
