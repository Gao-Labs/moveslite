#' `process()`
#' 
#' Function to run the process_by.R function in a loop
#' @param con ...
#' @param .level ...
#' @param .geoid ...
#' @param .by ...
#' @param .run ...
#' @param .pollutant ...
#' @param .tmp ...
#' @export
#' @import DBI
#' @import RMariaDB
#' @import RSQLite
#' @importFrom dplyr `%>%` 
#' @importFrom purrr map map_dfr
#' @author Tim Fraser, March 2023

process = function(con, .level = "county", .geoid = '36109',  .by = c(16, 8, 12, 14, 15),
                   .run = NULL, .pollutant = NULL, .tmp = "C:\\Users\\cjc384\\Desktop\\h.rds"){
  # .geoid must be supplied.
  # it can be a VECTOR of geoids from the same state
  # or a single geoid (eg. 1 state)
  # or a bunch of geoids (eg. 50 states)

  # Load connect() function
  #source("R/connect.R", local = TRUE)
  # Connect to MariaDB 'newdb' database (or whatever)
 
  # Requirements
  if(is.null(.geoid) | is.null(.level)){ print("Stopping: .geoid and .level both required."); stop() }
  if(is.null(con)){ print("Stopping: Local MariaDB connection must be specified in `.dbtype` and .dbname."); stop()   }
  if(.level == "county"){ print("Assuming all values in .geoid are from the same state... Bad news if not...")}
  
  # Load Packages
  #require(dplyr, warn.conflicts = FALSE)
  #require(readr, warn.conflicts = FALSE)
  #require(stringr, warn.conflicts = FALSE)
  #require(purrr, warn.conflicts = FALSE)
  #require(DBI, warn.conflicts = FALSE)
  #require(RMariaDB, warn.conflicts = FALSE)
  
  # Load process_by() function
  #source("R/process_by.R")
  
  # Initialize a temporary file to receive our calculations
  # by default, .tmp = "C:\\Users\\cjc384\\Desktop\\h.rrrr"
  # but you can change it as needed in the process function. 
  tmp = .tmp 
  
  # For each 'by' field 
  # By default, run these 5 'by' fields
  # (16 = overall, 8 = sourcetype, 12 = regclass, 14 = fueltype, 15= roadtype)
  .by %>%
    # Process data for each 'by' and the specific selected geoid, at the selected LEVEL
    map_dfr(~process_by(con = con, .by = ., .pollutant = .pollutant, 
                     .geoid = .geoid, .level = .level, .run = .run)) %>%
    # Save to file
    saveRDS(tmp)
  
  # Disconnect from local database and remove irrelevant data
  dbDisconnect(con); remove(con)
  
  # Return path to temporary file
  return(tmp)
}
