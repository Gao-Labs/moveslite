#' `get_geoid()`
#'
#' Extract list of unqiue geoids from a database connection.
#' connection must include tables "movesoutput" and "movesactivityoutput"
#' @param con ...
#' @import DBI 
#' @importFrom dplyr tbl select distinct collect `%>%`
#' @importFrom stringr str_pad
#' @export
#' @author Tim Fraser, Spring 2023

get_geoid = function(con){
  #require(DBI, warn.conflicts = FALSE)
  #require(dplyr, warn.conflicts = FALSE)
  #require(stringr, warn.conflicts = FALSE)
  
  # Get geoids available in emissions data
  .geoid.mo = con %>% tbl("movesoutput") %>% 
    select(geoid = countyID) %>% distinct() %>% collect() %>%
    with(geoid)
  
  # Get geoids available in activity data
  .geoid.mao = con %>% tbl("movesactivityoutput") %>% 
    select(geoid = countyID) %>% distinct() %>% collect() %>%
    with(geoid)
  
  # Identify just the subset of names from .geoid.mo that were in .geoid.mao
  .geoid = .geoid.mo[.geoid.mo %in% .geoid.mao]
  
  # Get number of spaces for formatting the geoid, based on the first one
  .spaces = max(nchar(.geoid))
  .spaces = if_else(.spaces > 2, true = 5, false = 2)
  
  # Pad them!
  result = str_pad(.geoid, width = .spaces, side = "left", pad = "0")
  return(result)
}
