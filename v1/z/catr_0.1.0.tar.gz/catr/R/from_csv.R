#' `from_csv()`
#' 
#' We have much data left over, stored as .csv format.
#' Let's take those moves output and moves activity output tables,
#' and initialize temporary .sqlite databases,
#' so that they may be supplied to the formatter() function naturally using connect().
#' @param mo ...
#' @param mao ...
#' @param .dbname ...
#' @param .level ...
#' @param .overwrite ...
#' @importFrom stringr str_extract
#' @import DBI
#' @import RSQLite
#' @export
#' @author Tim Fraser, March 2023

from_csv = function(mo, mao, .dbname = NULL, .level = "county", .overwrite = TRUE){
  
  # mo = "C:/Users/tmf77/OneDrive - Cornell University/Documents/rstudio/cat_invoker/data/pa_mo_moves31_ofra_2_276.csv"
  # mao = "C:/Users/tmf77/OneDrive - Cornell University/Documents/rstudio/cat_invoker/data/pa_mao_moves31_ofra_2_276.csv"
  # .dbname = "temp"
  # .dbtype = "sqlite"
  # .level = "county"
  # .overwrite = TRUE
  
  if(is.null(.dbname)){ .dbname = tempfile(fileext = ".sqlite") }
  
  # Get read_it function!
  # require(vroom, warn.conflicts = FALSE)
  # require(DBI, warn.conflicts = FALSE)
  # require(RSQLite, warn.conflicts = FALSE)
  # require(dplyr, warn.conflicts = FALSE)
  # require(readr, warn.conflicts = FALSE)
  # 
  # Connect/Establish a database
  local = DBI::dbConnect(RSQLite::SQLite(), .dbname)

  # Settings for overwriting
  if(.overwrite == TRUE){ .append = FALSE }else{ .append = TRUE}

  # Load read_it() function  
  #source("R/read_it.R", local = TRUE)
  #.level = "county"
  
  # Emissions
  data("metadata", envir = environment(), overwrite = TRUE)
  #metadata = read_rds("z/metadata.rds")[[.level]]
  metadata = metadata[[.level]]
  
  value = read_it(path = mo, metadata = metadata$emissions, .storage = TRUE)
  
  
  # Write emissions to file
  dbWriteTable(conn = local, name = "movesoutput", value = value,
               overwrite = .overwrite, append = .append)
  remove(value); gc()
  
  # Activity  
  value = read_it(path = mao, metadata = metadata$activity, .storage = TRUE)
  # Write activity to file
  dbWriteTable(conn = local, name = "movesactivityoutput", value = value,
               overwrite = .overwrite, append = .append)
  remove(value); gc()
  
  # Disconnect
  dbDisconnect(local); remove(local)
  
  # for:
  print( 
    paste0(
      "done: ",
      stringr::str_extract(mo, "[/]cat.*")
    )
  )
  # Return path to database
  return(.dbname)
}




