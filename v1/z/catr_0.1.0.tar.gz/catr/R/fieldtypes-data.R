#' `fieldtypes`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(fieldtypes)
#' @format ## `fieldtypes`
#' A named vector with 17 values:
#' \describe{
#'   \item{names}{name of variable}
#'   \item{values}{SQL encoding of variable eg. `"tinyint(2)"`}
#' ...
#' }
"fieldtypes"