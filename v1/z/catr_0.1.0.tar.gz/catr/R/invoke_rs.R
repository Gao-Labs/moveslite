#' `invoke_rs()`
#'
#' This function invokes MOVES from R.
#' @param .runspec ...
#' @param .dir ...
#' @param .moves  ...
#' @param background Default is TRUE. Invoke as a background job (TRUE), or in the console (FALSE)?
#' @importFrom rstudioapi jobRunScript
#' @importFrom readr write_lines
#' @importFrom stringr str_replace_all
#' @importFrom dplyr `%>%`
#' @export

invoke_rs = function(.runspec, .dir = NULL, .moves = NULL, background = TRUE){
  
  # If not listed, draw from environmental variables or defaults
  if(is.null(.moves)){ .moves = Sys.getenv("MOVES_FOLDER") }

  # If the directory is BLANK, we assume the runspec is FULLY specified.
  # If the directory is NOT blank, we assume the runspec is located WITHIN that directory
  if(!is.null(.dir)){ .runspec = paste0(.dir, "/", .runspec) }
  
  
  # Load packages!
  # require(dplyr,warn.conflicts = FALSE)
  # require(readr, warn.conflicts = FALSE)

  # Get a temporary file path to write our script
  temp = tempfile(pattern = "invoker_rs", fileext = ".R")
  
  # Write an R script... that writes a shell script...
  # the R script can be run as a background job.
  
  paste(
    "# Run the following code in the shell!",
    "shell(",
    "# Insert command line code, as 1 line, punctuated by &&",
    paste0(
      "  cmd = 'cd ",
      # Set directory to MOVES
      paste0('"', str_replace_all(.moves, "/", "\\\\\\\\"),  '" '),
      ' && ',
      # Set environment with MOVES specifications
      'setenv',
      ' && ',
      # Load ant
      'ant',
      ' && ',
      # Run your runspec
      paste0('ant run -Drunspec="', str_replace_all(.runspec, "/", "\\\\\\\\"), '"'),
      " ",
      "', "),
    "  translate = TRUE, intern = FALSE, mustWork = TRUE",
    ")",    
    sep = "\n"
  ) %>%
    readr::write_lines(x = ., file = temp)
  
  # View the file!
  #rstudioapi::documentOpen(temp) # For testing only
  
  
  # Want to invoke it as a background job?
  if(background == TRUE){  
    # Load translate_rs() function
    # source("R/translate_rs.R")
    # Save list of key values as object 'rs'; just extract these 4 elements
    rs = translate_rs(.runspec = .runspec)[ c("default", "level", "geoid", "year") ]
    
    # Make a name for the job.
    .name = if(rs$default == TRUE){"default"}else{"custom"}
    .name = paste0(.name, "-", rs$level, "-", rs$geoid[1], "-", rs$year[1])
    
    # Now start a background job with that temporary path
    rstudioapi::jobRunScript(
      path = temp,
      name = .name, 
      # Use directory of the temp file
      workingDir = dirname(temp))
  }else{
    # Want to invoke it as-is in the current working terminal?
    source(file = temp)
  }
  
  return(temp)
  
  print("---MOVES invoked!")  
}
