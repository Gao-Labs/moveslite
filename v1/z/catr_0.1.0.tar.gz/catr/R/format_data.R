#' `format_data()`
#'
#' Format MOVES output data into CAT data. 
#' @param .level eg. "state"
#' @param .geoid eg. "17" (Illinois)
#' @param .run   # Specific MOVESRunID? (eg. 1)? If not, leave NULL.
#' @param .pollutant Specific Pollutant (eg. 98)? If not, leave  NULL.
#' @param .by Aggregation levels to be used when looping. Use defaults below, or talk to Tim.
#' @param con Optional. Connection.
#' @param .tmp Optional. Temporary path default.
#' @export

format_data = function(
  .level = "state", .geoid = "17",
  .run = NULL, .pollutant = NULL, .by = c(16, 8, 12, 14, 15),
  con, .tmp = NULL
  ){
  
  # If no .con provided, use the .outputdbname from keys.R
  if(is.null(con)){ connect("mariadb", Sys.getenv("OUTPUTDBNAME"))  }

  # If missing a temporary folder, make one here.
  if(is.null(.tmp)){
    # Get a temporary file path
    .tmp = tempfile(tmpdir = Sys.getenv("TEMP_FOLDER"), fileext = ".rds")
    # Fix the backslashes
    .tmp = stringr::str_replace_all(.tmp, "[/]|\\\\", replacement = "//")
  }
  
  # 1. PACKAGES ###
  
  # Load packages needed in this function. 
  #require(dplyr, warn.conflicts = FALSE) # data wrangling, pipelines
  #require(readr, warn.conflicts = FALSE) # reading in data; read_rds, read_csv, etc.
  #require(purrr, warn.conflicts = FALSE)
  
  # 2. PROCESS DATA ###
  
  # Load process() function
  #source("R/process.R", local = TRUE)
  
  # Process function data for specified .geoid and level, for selected '.by' fields, for a given .run ID (optional)
  path = process(con = con, .level = .level, .geoid = .geoid, 
                 .by = .by, .pollutant = .pollutant, .run = .run, .tmp = .tmp)
  #remove(process)
  
  # Print completion message
  print("---processing: done")
  print(paste("---path: ", path))
  
  
  # Always return the file path, in case you want to check it with readr::read_rds()
  return(path)
}
