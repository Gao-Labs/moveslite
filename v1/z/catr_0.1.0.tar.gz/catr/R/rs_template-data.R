#' `rs_template`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(rs_template)
#' @format ## `rs_template`
#' A list object containing a template runspec file
#' 
"rs_template"