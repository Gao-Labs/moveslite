#' `pollutant`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(pollutant)
#' @format ## `pollutant`
#' A named data.frame with 21 rows and 3 columns:
#' \describe{
#'   \item{id}{Unique ID for each pollutant}
#'   \item{term}{Full name of each pollutant}
#'   \item{label}{Shortened Name of each pollutant}
#' ...
#' }
"pollutant"