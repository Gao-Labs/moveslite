#' `get_runid()`
#' 
#' Function to get the MOVESRunID for your most recent moves run.
#' @param .outputdbname Optional. Defaults to Sys.getenv("OUTPUTDBNAME"), set in your keys.R file.
#' @param n number of most recent runs to return data for. Default is 1. Max is 100.
#' @param id TRUE
#' @export
#' @import DBI
#' @import RMariaDB
#' @importFrom dplyr `%>%` collect summarize tbl filter

get_runid = function(.outputdbname = NULL, n = 1, id = TRUE){
  
  # Testing parameters
  #.outputdbname = NULL;
  # n = 1;
  #id = TRUE;
  
  # Load connect function
  # source("R/connect.R")
  # source("keys.R")
  
  .outputdbname = if(is.null(.outputdbname)){ Sys.getenv("OUTPUTDBNAME") }
  
  # Get the ID of the most recent moves run!
  local = connect(.type = "mariadb", .name = .outputdbname) 
  
  # Get your MOVES output database to return the last 100 runs.
  series = local %>% tbl("movesrun") %>%
    summarize(last = max(MOVESRUNID, na.rm = TRUE)) %>% 
    collect() %>%
    with(last)
  
  # If you ask for multiple runs, use 'last' to search for them.
  if(n > 1){
    # Extract the last id
    last = series$last
    # Now get the first id; default to 1 if it goes negative
    first = last - n;  first = if(first < 1){ 1}else{first}
    # Make a vector spanning from the first to last id
    series = first:last
  }
  
  # Filter to that range of records and collect it.
  result = local %>%
    tbl("movesrun") %>%
    filter(MOVESRunID %in% !!series) %>%
    collect()
  
  # Disconnect!
  dbDisconnect(local); remove(local)
  
  # If id == TRUE, only return the IDs. Otherwise, return the data.frame
  if(id == TRUE){ result = result$MOVESRunID }
  
  # Return the Run information 
  return(result)
}
