#' `adapt()`
#'
#' This function adapts existing default data to a new custom input database.
#' @param .changes description TBA.
#' @param .runspec description TBA.
#' @importFrom dplyr `%>%` mutate filter tbl collect
#' @importFrom stringr str_remove str_extract
#' @importFrom readr read_csv
#' @importFrom tidyr expand_grid
#' @import DBI
#' @import RMariaDB
#' @import RSQLite
#' @export

adapt = function(.runspec, .changes = NULL){

  # a script to 'adapt' existing default data to a new 'custom' db
  
  # Testing values:
  # .changes = NULL
  # .runspec = "invoker/rs_template.xml"
  # .local = Sys.getenv("MDB_DEFAULT"); .custom = "custom"
  # require(dplyr)
  # require(readr)
  # require(tidyr)
  # require(stringr)
  # require(DBI)

  
  # 1. RUNSPEC ###################################################
  
  # Load translate_rs() function
  
  # Save list of key values as object 'rs'
  rs = translate_rs(.runspec = .runspec)
  
  # Relabel key values from runspec.
  .year = rs$year # eg. 2020
  .geoid = rs$geoid %>% as.integer() # eg. 36109
  .pollutant = rs$pollutant # NULL,
  .month = rs$month # eg. 1:12,
  .hour = rs$hour # eg. 1:24, 
  .day = rs$day  # eg. c(2,5)
  .hourday = tidyr::expand_grid(hour = .hour, day = .day) %>% 
    mutate(hourday = paste0(hour, day)) %>% with(hourday) 
  .custom = rs$inputdbname
  
  
  # 2. CONNECTIONS #################################################
  
  # Connect to default MOVES inputs
  local = connect("mariadb", Sys.getenv("MDB_DEFAULT"))
  # Initialize/connect to mariadb database "custom"
  custom = connect("mariadb", .custom)
  
  
  # 3. PORT DEFAULT TABLES ###############################################
  
  ## 3.1 YEAR #########################################################
  .table = "year"
  local %>% tbl(.table) %>% filter(yearID %in% !!.year) %>% collect() %>% 
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "hpmsvtypeyear"
  local %>% tbl(.table) %>% filter(yearID %in% !!.year) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "sourcetypeagedistribution"
  local %>% tbl(.table) %>% filter(yearID %in% !!.year) %>% collect()  %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "sourcetypeyear"
  myvalues = local %>% tbl(.table) %>% filter(yearID %in% !!.year) %>% collect()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "monthvmtfraction"
  local %>% tbl(.table) %>% filter(monthID %in% !!.month) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "startshourfraction"
  local %>% tbl(.table) %>% filter(dayID %in% !!.day, hourID %in% !!.hour) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "fuelsupply"
  local %>% tbl(.table)  %>% filter(fuelYearID %in% !!.year, monthGroupID %in% !!.month) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "fuelusagefraction"
  local %>% tbl(.table) %>% filter(countyID %in% !!.geoid, fuelYearID  %in% !!.year) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "startshourfraction"
  local %>% tbl(.table) %>% filter(dayID %in% !!.day, hourID %in% !!.hour) %>% collect() %>% 
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  ## 3.2 COUNTY #######################################################
  
  # Get county table
  .table = "county"
  myvalues = local %>% tbl(.table) %>% filter(countyID %in% !!.geoid) %>% collect()
  myvalues %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  # Set countytype
  .countytype = myvalues$countyTypeID %>% unique()
  # Set state
  .state = myvalues$stateID %>% unique()
  
  
  .table = "state"
  myvalues = local %>% tbl(.table) %>% filter(stateID %in% !!.state) %>% collect()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  # Set idleregion
  .idleregion = myvalues$idleRegionID %>% unique()
  
  
  .table = "idleregion"
  local %>% tbl(.table) %>% filter(idleRegionID %in% !!.idleregion) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "totalidlefraction"
  myvalues = local %>% tbl(.table) %>% 
    filter(idleRegionID %in% !!.idleregion, 
           countyTypeID %in% !!.countytype,
           monthID %in% !!.month,
           dayID %in% !!.day) %>%
    collect()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "imcoverage"
  myvalues = local %>% tbl(.table) %>% 
    filter(stateID %in% !!.state, countyID %in% !!.geoid, yearID %in% !!.year)  %>% collect()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  ## 3.3 ZONES ########################################################
  # Get zone table
  .table = "zone"
  myvalues = local %>% tbl(.table) %>% filter(countyID %in% !!.geoid) %>% collect()
  
  myvalues %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  # Set zone names
  .zone = myvalues$zoneID
  
  # Use .zone from above to get zonemonthhour data
  .table = "zonemonthhour"
  local %>% tbl(.table) %>% 
    filter(zoneID %in% !!.zone, monthID %in% !!.month, hourID %in% !!.hour) %>%
    collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "zoneroadtype"
  # Get roadtypes within our zones
  myvalues = local %>% tbl(.table) %>% filter(zoneID %in% !!.zone) %>% collect()
  myvalues %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  # Set roadtype names
  .roadtype = myvalues$roadTypeID %>% unique()
  
  
  .table = "hotellingactivitydistribution"
  local %>% tbl(.table) %>% filter(zoneID %in% !!.zone) %>% collect() %>% 
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "dayvmtfraction"
  local %>% tbl(.table) %>% 
    filter(monthID %in% !!.month & dayID %in% !!.day & roadtypeID %in% !!.roadtype) %>%
    collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "avgspeeddistribution"
  local %>% tbl(.table) %>% filter(roadTypeID %in% !!.roadtype,
                                   hourDayID %in% !!.hourday) %>% collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  .table = "hourvmtfraction"
  local %>% tbl(.table) %>% 
    filter(roadTypeID %in% !!.roadtype, dayID %in% !!.day, hourID %in% !!.hour) %>% 
    collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "roadtypedistribution"
  local %>% tbl(.table) %>% filter(roadTypeID %in% !!.roadtype) %>%
    collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  .table = "startsperdaypervehicle"
  local %>% tbl(.table) %>% filter(dayID %in% !!.day) %>%  collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)
  
  
  ## 3.4 POLLUTANT #########################################################################
  .table = "pollutantprocessassoc"
  myvalues = local %>% tbl(.table) %>% filter(pollutantID %in% !!.pollutant) %>% collect()
  .polprocess = myvalues$polProcessID %>% unique()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = T, append = F)
  
  .table = "opmodepolprocassoc"
  myvalues = local %>% tbl(.table) %>% filter(polProcessID %in% !!.polprocess) %>% collect()
  .opmode = myvalues$opModeID %>% unique()
  myvalues %>% dbWriteTable(conn = custom, name = .table, value = ., overwrite = T, append = F)
  
  .table = "startsopmodedistribution"
  local %>% tbl(.table) %>% filter(opModeID %in% !!.opmode, dayID %in% !!.day, hourID %in% !!.hour) %>% 
    collect() %>%
    dbWriteTable(conn = custom, name = .table, value = ., overwrite = T, append = F)
  
  
  ## 3.5 Unaffected
  .vars = c("startsageadjustment", "startsmonthadjust")
  for(i in .vars){
    .table = i    
    local %>% tbl(.table) %>% collect() %>%
      dbWriteTable(conn = custom, name = .table, value = ., overwrite = TRUE, append = FALSE)    
  }
  
  
  
  # 4. CHANGES #########################################################
  
  # Run the script of changes provided, if any.
  if(!is.null(.changes)){
    
    
    # For each script provided
    for(i in .changes){
      filetype = i %>% tolower() %>% str_extract("[.]r|[.]csv")
      # If it's an R script (deprecated; soon to be removed)
      if(filetype == ".r"){    
        # Run that script
        source(i, local = TRUE)
        # If it's a csv file
      }else if(filetype == ".csv"){
        # Extract the table name from it.
        .table = i %>% str_remove(".*[/]") %>% tolower() %>% str_remove("[.]csv")
        
        # Read the csv file
        contents = readr::read_csv(i)
        if(nrow(contents) > 0){
          # Write it to the custom database with that table name.
          dbWriteTable(conn = custom, name = .table, value = contents, overwrite = TRUE, append = FALSE)
        }
        # note: the table name MUST be one of the MOVES input table names.
        remove(.table, contents, filetype)
      }
      
    }
  }
  
  
  # Z. DISCONNECT #####################################################
  # Always, always, always disconnect.
  dbDisconnect(local); remove(local)
  dbDisconnect(custom); remove(custom)
  
  
  print("---done!")
  
}
