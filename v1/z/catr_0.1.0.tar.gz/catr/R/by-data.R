#' `by`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(by)
#' @format ## `by`
#' A data frame with 16 rows and 2 columns:
#' \describe{
#'   \item{id}{'by' id for each distinct level of disaggregation}
#'   \item{term}{Names of variables for that level of disaggregation}
#'   ...
#' }
"by"