#' `types`: Helper Data for running `catr` package functions
#'
#' @docType data 
#' @usage data(types)
#' @format ## `types`
#' A data.frame of 6 rows and 5 columns
#' \describe{
#'   \item{level}{...}
#'   \item{prefix}{...}
#'   \item{type}{...}
#'   \item{table}{...}
#'   \item{path}{...}
#' ...
#' }
#' 
"types"