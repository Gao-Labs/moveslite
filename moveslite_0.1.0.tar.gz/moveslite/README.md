# moveslite

- Authors: Tim Fraser, Yan Guo, and Oliver Gao
- Description: repository for `moveslite` R package and validation analyses.

## Links

- [Our paper's Google Doc](https://docs.google.com/document/d/1_BoWuk7iNKHp_mEChzfh_IDNt-jN6pp_MtpL5cE22EM/edit?usp=sharing)

- [Google Slides](https://docs.google.com/presentation/d/1vou61QQLnUnoZsAcCo0hOjLhD9uJxFRa4l3lDEbvuRA/edit?usp=sharing)

- [R Packages Guide](https://r-pkgs.org/)

